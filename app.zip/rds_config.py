#config file containing credentials for rds mysql instance
db_username = "Manugr21"
db_password = "12345678"
db_name = "manuDB" 
