import sys
import logging
import rds_config
import pymysql
import boto3

#rds settings
rds_host  = "id13ycboax6nv7x.c4863skzvjnn.us-east-2.rds.amazonaws.com"
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

s3 = boto3.client('s3')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
def handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    response = s3.head_object(Bucket=bucket, Key=key)
    title = response['Metadata']['titulo']
    url = s3.generate_presigned_post(bucket, key, Fields=None, Conditions=None, ExpiresIn = 100)
    item_count = 0
    with conn.cursor() as cur:
        cur.execute("CREATE TABLE IF NOT EXISTS Images ( id  int NOT NULL AUTO_INCREMENT, title varchar(255) NOT NULL, url varchar(255) NOT NULL, PRIMARY KEY (id))")
        cur.execute("INSERT INTO Images (title, url) VALUES('" + title + "','" + url['url'] + "/" + url['fields']['key'] + "')")
        conn.commit()
        cur.execute("SELECT * FROM Images")
        for row in cur:
            item_count += 1
            logger.info(row)
            #print(row)

    return "Added %d items from RDS MySQL table" %(item_count)
